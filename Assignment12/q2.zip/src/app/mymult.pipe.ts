import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mymult'
})
export class MymultPipe implements PipeTransform {

  transform(value:number,param:number): number
  {
    let ans:number;
    ans = value * param;
    return ans; 
  }

}
