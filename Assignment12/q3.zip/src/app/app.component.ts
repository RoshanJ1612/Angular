import { Component } from '@angular/core';
import { MarvellouschkPipe } from './marvellouschk.pipe';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'q3';
  No:number = 11;
}
