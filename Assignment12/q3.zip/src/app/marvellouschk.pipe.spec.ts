import { MarvellouschkPipe } from './marvellouschk.pipe';

describe('MarvellouschkPipe', () => {
  it('create an instance', () => {
    const pipe = new MarvellouschkPipe();
    expect(pipe).toBeTruthy();
  });
});
