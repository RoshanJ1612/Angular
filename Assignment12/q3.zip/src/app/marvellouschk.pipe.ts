import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellouschk'
})
export class MarvellouschkPipe implements PipeTransform 
{   


  transform(value:number , param:string):string
  {

    let ans:string = ""; 
      if(param == "Prime")
      {   
          let i: number = 2;
          
          for(i = 2; i<=value/2;i++)
          {
            if(value % i == 0)
            {
             
              break;
            }
           
          }
          if(i>=value/2)
          {
            ans = "It is a Prime Number";
          }
          else
          {
            ans = "It is not a Prime Number";
          }
      }
      
        
      if(param == "Perfect")
      {
          let i: number = 1;
          let sum:number = 0;
          for(i = 1; i<=value/2;i++)
          {
            sum = sum + i;
           
          }
          if(sum == value)
          {
            ans = "It is a Perfect Number";
          }
          else
          {
            ans = "It is Not a Perfect Number";
          }
      }

      if(param == "Even")
      {
        if(value % 2 == 0)
        {
            ans = "It is Even Number";
        }
        else
        {
          ans = "It is not Even Number";
        }
      }

      if(param == "Odd")
      {
        if(value % 2 == 0)
        {
          ans =  "It is not Odd Number";
        }
        else
        {
          ans=  "It is Odd Number";
        }
      }
      return ans;
  }

}
