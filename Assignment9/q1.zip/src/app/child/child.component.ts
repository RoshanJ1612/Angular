import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';
@Component({
  selector: 'app-child',
  template: `
  <h1>Inside Child(Demo) Component</h1>
<h1>Addition is {{ans1}}</h1>
<h1>Subtraction is {{ans2}}</h1>
  `
})
export class ChildComponent implements OnInit {

  public ans1:any;
  public ans2:any;
  constructor(private _obj : ArithmeticService) {}

  ngOnInit(): void 
  {
        this.ans1 = this._obj.Add(11,21);
        this.ans2 = this._obj.sub(21,11);

  }

}
