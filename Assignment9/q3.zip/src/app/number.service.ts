import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  constructor() { }
  public ChkPrime(no1:number):boolean
  {
    var i:number = 0;
    var ans:boolean = true;
    for(i = 2;i <= no1/2;i++)
    {
        if(no1 % i != 0)
        {
            ans = false;
            break;
        }
    }
    return ans;
  }
}
