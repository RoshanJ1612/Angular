import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';


@Component({
  selector: 'app-child',
  template:`
  <h1>Inside child  component</h1>
  <hr>
  <h1>Given number is {{no1}}</h1>
<ng-template #prime>
  <h1>Given number is prime number</h1>
</ng-template>

<ng-template #noprime>
  <h1>Given number is not a prime number</h1>
</ng-template>
<h1 *ngIf="ans1; then noprime;else prime"></h1>
<hr>
<h1>Given string is {{str}}</h1>
<h1>Count of capital letters are {{cnt}}</h1>


  `
})
export class ChildComponent implements OnInit {

  no1:number = 7;
  ans1:boolean = true;

  cnt:number = 0;
  public str = "Marvellous Infosytem";

  constructor(private _obj1:NumberService,private _obj2:StringService) { }

  ngOnInit(): void {
    this.ans1= this._obj1.ChkPrime(this.no1);
    this.cnt = this._obj2.CountCapital(this.str);
  }

}
