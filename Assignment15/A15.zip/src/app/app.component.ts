import { Component } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
 states:any;

    constructor(public fbobj : FormBuilder)
  {
    this.states =  [
      {Id : "Maharashtra", Name:"Maharashtra"},
      {Id : "Gujarat", Name:"Gujarat"},
      {Id : "Uttar Pradesh", Name:"Uttar Pradesh"}
    ];
  }

  get f(){
    return this. MarvellousForm.controls;
  }
  MarvellousForm = this.fbobj.group(
    {
      // Add validations
      firstname :['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$') ]],
      lastName : ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$') ]],
      Email:['', [Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]],
      PhoneNo:['', [ Validators.required,Validators.pattern('^[0-9]*$'),Validators.minLength(10), Validators.maxLength(10)]],
      City:['',[Validators.required,, Validators.minLength(4),Validators.pattern('^[a-zA-Z ]*$')]],
      state:['',Validators.required],
      ZipCode:['', [ Validators.required,Validators.pattern('^[0-9]*$'),Validators.minLength(5), Validators.maxLength(5)]],
      Comment:['',[Validators.required,Validators.minLength(30)]]
      
    }
  );
  
}
