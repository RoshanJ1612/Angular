import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]'
})
export class CompSuccessDirective {

  constructor(private _ele:ElementRef) 
  { }

  @HostListener('mouseenter') onmouseenter()
  {
    this._ele.nativeElement.style.color = 'green';
  }

  @HostListener('mouseleave') onmouseleave()
  {
    this._ele.nativeElement.style.color = "black";
  }

}
