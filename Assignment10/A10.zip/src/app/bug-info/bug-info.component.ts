import { Component, ViewEncapsulation, OnInit,LOCALE_ID} from '@angular/core';
import {MatCalendarCellClassFunction} from '@angular/material/datepicker';
import { NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bug-info',
  templateUrl: './bug-info.component.html',
  styleUrls: ['./bug-info.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class BugInfoComponent
{
  //time: NgbTimeStruct = {hour: 13, minute: 30, second: 30};
  //seconds = true;
  gfg1 = {hour: 15, minute: 58};




  dateClass: MatCalendarCellClassFunction<Date> = (cellDate, view) => {
    // Only highligh dates inside the month view.
    if (view === 'month') {
      const date = cellDate.getDate();

      // Highlight the 1st and 20th day of each month.
      return date === 1 || date === 20 ? 'example-custom-date-class' : '';
    }

    return '';
  };

}
