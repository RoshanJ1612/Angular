import { Component, Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-c1',
  templateUrl: './c1.component.html',
  styleUrls: ['./c1.component.css']
})
export class C1Component  
{

 
  @Output() public Myevent = new EventEmitter();

  public SendMessageToParent(data:any)
  {
    this.Myevent.emit(data);
  }

  @Input() public MsgFromParent:any;
  @Input() public Flag:any;
}
