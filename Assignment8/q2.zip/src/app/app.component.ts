import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'q2';
  //----------CHILD TO PARENT-----------
  public ChildMsg:any;
  public Mode = 0;
  public CommunicationPtoC()
  {
    this.Mode = 1;
  } 
  public CommunicationCtoP()
  {
    this.Mode = 2;
  }

  //-----------PARENT TO CHILD--------
  public  MsgForChild:any;
  public SendMessageTochild(data:any)
  {
    this.MsgForChild = data;
  }
}
