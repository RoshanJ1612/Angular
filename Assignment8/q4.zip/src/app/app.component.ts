import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'q4';
  public strLength:any;
  public str:any;
  public calculateLength(data:string)
  {
    this.str = data;
    this.strLength = this.str.length;
  }



}
