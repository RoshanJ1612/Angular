import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent 
{
    public Data = "Marvellous Infosystem";
    public Data1 = " ";

    public lower()
    {
      this.Data1 = this.Data.toLowerCase();
    }

    public upper()
    {
      this.Data1 = this.Data.toUpperCase();

    }

      
 }

  


