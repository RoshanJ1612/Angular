import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template:`
  <h1>Inside child 1 component</h1>
  <h1>Given number is {{no1}}</h1>
<ng-template #prime>
  <h1>Given number is prime number</h1>
</ng-template>

<ng-template #noprime>
  <h1>Given number is not a prime number</h1>
</ng-template>
<h1 *ngIf="ans1; then noprime;else prime"></h1>
  
  `
  
  
})
export class Child1Component implements OnInit {

  no1:number = 7;
  ans1:boolean = true;
  constructor(private _obj:NumberService) { }

  ngOnInit(): void {

    this.ans1= this._obj.ChkPrime(this.no1);
   

  }

}
