import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  public CountCapital(data:string):number
  {
    var copy:string = data.toLowerCase();
    var i:number = 0;
    var cnt:number = 0;
    for(i = 0; i <data.length;i++)
       {
        if(data[i] != copy[i])
        {
          cnt++;
        }
       } 
        return cnt;
  }

}
