import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';
@Component({
  selector: 'app-child2',
  template:`<h1>Inside Child two component</h1>
  <h1>Given string is {{str}}</h1>
  <h1>Count of capital letters are {{cnt}}</h1>
  `
})
export class Child2Component implements OnInit {

  cnt:number = 0;
  public str = "Marvellous Infosytem";
  constructor(private _obj:StringService) { }

  ngOnInit(): void {
    this.cnt = this._obj.CountCapital(this.str);
  }

}
