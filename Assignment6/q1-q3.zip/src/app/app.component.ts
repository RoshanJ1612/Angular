import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:'<h1>Marvellous Infosytem </h1> <input type="text">',
  styles:['h1{color : blue;}']

})
export class AppComponent {
  title = 'Demo';
}
