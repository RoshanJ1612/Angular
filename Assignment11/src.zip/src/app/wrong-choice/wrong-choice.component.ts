import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrong-choice',
  templateUrl: './wrong-choice.component.html'
})
export class WrongChoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
